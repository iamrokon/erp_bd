<?php
/**********************************************************************
    Copyright (C) NGICON (Next Generation icon) ERP.
	Released under the terms of the GNU General Public License, GPL,
	as published by the Free Software Foundation, either version 3



    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 All Rights Reserved By www.ngicon.com
***********************************************************************/
class inventory_app extends application
{
	function __construct()
	{
		parent::__construct("stock", _($this->help_context = "&Items & Stock"));

		$this->add_module(_("Transactions"));
if (get_company_pref('SA_LOCATIONTRANSFER'))
		$this->add_lapp_function(0, _("Inventory Location &Transfers"),
			"inventory/transfers.php?NewTransfer=1", 'SA_LOCATIONTRANSFER', MENU_TRANSACTION);
if (get_company_pref('SA_INVENTORYADJUSTMENT'))
			$this->add_lapp_function(0, _("Inventory &Adjustments"),
			"inventory/adjustments.php?NewAdjustment=1", 'SA_INVENTORYADJUSTMENT', MENU_TRANSACTION);

		$this->add_module(_("Inquiries and Reports"));
if (get_company_pref('SA_ITEMSTRANSVIEW'))
		$this->add_lapp_function(1, _("Inventory Item &Movements"),
			"inventory/inquiry/stock_movements.php?", 'SA_ITEMSTRANSVIEW', MENU_INQUIRY);
if (get_company_pref('SA_ITEMSSTATVIEW'))
			$this->add_lapp_function(1, _("Inventory Item &Status"),
			"inventory/inquiry/stock_status.php?", 'SA_ITEMSSTATVIEW', MENU_INQUIRY);
if (get_company_pref('SA_ITEMSTRANSVIEW'))
			$this->add_rapp_function(1, _("Inventory &Reports"),
			"reporting/reports_main.php?Class=2", 'SA_ITEMSTRANSVIEW', MENU_REPORT);

		$this->add_module(_("Maintenance"));
if (get_company_pref('SA_ITEM'))
		$this->add_lapp_function(2, _("&Items"),
			"inventory/manage/items.php?", 'SA_ITEM', MENU_ENTRY);
if (get_company_pref('SA_FORITEMCODE'))
			$this->add_lapp_function(2, _(" Items Multi Pack"),
			"inventory/manage/item_codes.php?", 'SA_FORITEMCODE', MENU_MAINTENANCE);
if (get_company_pref('SA_SALESKIT'))
			$this->add_lapp_function(2, _("Create Sales Packages"),
			"inventory/manage/sales_kits.php?", 'SA_SALESKIT', MENU_MAINTENANCE);
if (get_company_pref('SA_ITEMCATEGORY'))
			$this->add_lapp_function(2, _("Item &Categories"),
			"inventory/manage/item_categories.php?", 'SA_ITEMCATEGORY', MENU_MAINTENANCE);
if (get_company_pref('SA_INVENTORYLOCATION'))
			$this->add_rapp_function(2, _("Warehouse | Stock Locations"),
			"inventory/manage/locations.php?", 'SA_INVENTORYLOCATION', MENU_MAINTENANCE);
if (get_company_pref('SA_UOM'))
			$this->add_rapp_function(2, _("&Units of Measure"),
			"inventory/manage/item_units.php?", 'SA_UOM', MENU_MAINTENANCE);
if (get_company_pref('SA_REORDER'))
			$this->add_rapp_function(2, _("&Reorder Levels"),
			"inventory/reorder_level.php?", 'SA_REORDER', MENU_MAINTENANCE);

		$this->add_module(_("Pricing and Costs"));
if (get_company_pref('SA_SALESPRICE'))
		$this->add_lapp_function(3, _("Sales &Pricing"),
			"inventory/prices.php?", 'SA_SALESPRICE', MENU_MAINTENANCE);
if (get_company_pref('SA_PURCHASEPRICING'))
			$this->add_lapp_function(3, _("Purchasing &Pricing"),
			"inventory/purchasing_data.php?", 'SA_PURCHASEPRICING', MENU_MAINTENANCE);
if (get_company_pref('SA_STANDARDCOST'))
			$this->add_rapp_function(3, _("Standard &Costs"),
			"inventory/cost_update.php?", 'SA_STANDARDCOST', MENU_MAINTENANCE);

		$this->add_extensions();
	}
}


